<?php
header('Access-Control-Allow-Origin:https://alexart.local');
var_dump($_POST);
var_dump($_FILES);
?>